import sys
import subprocess
subprocess.check_call([sys.executable, '-m', 'pip', 'install', 'pillow'])
subprocess.check_call([sys.executable, '-m', 'pip', 'install', 'python-docx'])
subprocess.check_call([sys.executable, '-m', 'pip', 'install', 'PyPDF2'])
subprocess.check_call([sys.executable, '-m', 'pip', 'install', 'docx' ])
subprocess.check_call([sys.executable, '-m', 'pip', 'install', 'python-docx'])
subprocess.check_call([sys.executable, '-m', 'pip', 'install', 'pdf2image'])
subprocess.check_call([sys.executable, '-m', 'pip', 'install', 'docx2pdf'])
subprocess.check_call([sys.executable, '-m', 'pip', 'install', 'customtkinter'])
subprocess.check_call([sys.executable, '-m', 'pip', 'install', 'aspose-words'])
subprocess.check_call([sys.executable, '-m', 'pip', 'install', 'tk'])